from flask import Blueprint, request, jsonify
import requests
import os
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

webhook_bp = Blueprint('webhook', __name__)

# Configurações
WHATSAPP_TOKEN = os.getenv('WHATSAPP_TOKEN', 'your_whatsapp_token_here')
VERIFY_TOKEN = os.getenv('VERIFY_TOKEN', 'meu_token_verificacao_123')
HUGGINGFACE_API_KEY = os.getenv('HUGGINGFACE_API_KEY', 'your_hf_token_here')

# URL da API do Hugging Face (modelo gratuito)
HF_API_URL = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"

@webhook_bp.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verificação do webhook pelo WhatsApp"""
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    logger.info(f"Verificação webhook - Mode: {mode}, Token: {token}")
    
    if mode == 'subscribe' and token == VERIFY_TOKEN:
        logger.info("Webhook verificado com sucesso!")
        return challenge
    
    logger.warning("Falha na verificação do webhook")
    return 'Forbidden', 403

@webhook_bp.route('/webhook', methods=['POST'])
def handle_webhook():
    """Processa mensagens recebidas do WhatsApp"""
    data = request.get_json()
    logger.info(f"Webhook recebido: {data}")
    
    if 'entry' in data:
        for entry in data['entry']:
            for change in entry['changes']:
                if 'messages' in change['value']:
                    for message in change['value']['messages']:
                        process_message(message, change['value']['metadata'])
    
    return jsonify({'status': 'success'})

def process_message(message, metadata):
    """Processa uma mensagem individual"""
    phone_number_id = metadata['phone_number_id']
    from_number = message['from']
    message_text = message.get('text', {}).get('body', '')
    
    logger.info(f"Mensagem recebida de {from_number}: {message_text}")
    
    if message_text:
        # Gera resposta usando Hugging Face (GRATUITO)
        ai_response = generate_huggingface_response(message_text)
        
        # Envia resposta de volta
        send_whatsapp_message(phone_number_id, from_number, ai_response)

def generate_huggingface_response(user_message):
    """Gera resposta usando Hugging Face API (GRATUITO)"""
    
    # Respostas pré-definidas para economizar API calls
    quick_responses = {
        'oi': 'Olá! Como posso ajudá-lo hoje?',
        'olá': 'Oi! Em que posso ser útil?',
        'obrigado': 'De nada! Fico feliz em ajudar!',
        'obrigada': 'De nada! Fico feliz em ajudar!',
        'tchau': 'Até logo! Volte sempre que precisar!',
        'bye': 'Até mais! Tenha um ótimo dia!',
        'help': 'Estou aqui para ajudar! Digite sua pergunta e eu farei o meu melhor para responder.',
        'ajuda': 'Estou aqui para ajudar! Digite sua pergunta e eu farei o meu melhor para responder.'
    }
    
    # Verificar se há resposta rápida
    if user_message.lower().strip() in quick_responses:
        return quick_responses[user_message.lower().strip()]
    
    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "inputs": user_message,
        "parameters": {
            "max_length": 100,
            "temperature": 0.7,
            "do_sample": True,
            "return_full_text": False
        }
    }
    
    try:
        logger.info(f"Enviando para Hugging Face: {user_message}")
        response = requests.post(HF_API_URL, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            logger.info(f"Resposta HF: {result}")
            
            if isinstance(result, list) and len(result) > 0:
                generated_text = result[0].get('generated_text', '').strip()
                if generated_text:
                    return generated_text
                else:
                    return "Interessante! Pode me contar mais sobre isso?"
            else:
                return "Entendi! Como posso ajudá-lo com isso?"
        else:
            logger.error(f"Erro HF API: {response.status_code} - {response.text}")
            return "Desculpe, estou com dificuldades técnicas. Tente novamente em alguns instantes."
            
    except requests.exceptions.Timeout:
        logger.error("Timeout na API Hugging Face")
        return "Desculpe, a resposta está demorando. Tente novamente."
    except Exception as e:
        logger.error(f"Erro na API Hugging Face: {e}")
        return "Desculpe, ocorreu um erro. Tente novamente mais tarde."

def send_whatsapp_message(phone_number_id, to_number, message_text):
    """Envia mensagem via WhatsApp Business API"""
    url = f"https://graph.facebook.com/v18.0/{phone_number_id}/messages"
    
    headers = {
        'Authorization': f'Bearer {WHATSAPP_TOKEN}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'messaging_product': 'whatsapp',
        'to': to_number,
        'text': {'body': message_text}
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        logger.info(f"Resposta WhatsApp API: {response.status_code} - {response.text}")
        return response.json()
    except Exception as e:
        logger.error(f"Erro ao enviar mensagem WhatsApp: {e}")
        return None

