#!/usr/bin/env python3
"""
Script de teste para validar o funcionamento do webhook do chatbot WhatsApp
"""

import requests
import json
import time

# Configurações de teste
BASE_URL = "http://localhost:5000"
VERIFY_TOKEN = "meu_token_verificacao_123"

def test_health_check():
    """Testa o endpoint de health check"""
    print("🔍 Testando health check...")
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health check OK: {data}")
            return True
        else:
            print(f"❌ Health check falhou: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Erro no health check: {e}")
        return False

def test_webhook_verification():
    """Testa a verificação do webhook"""
    print("🔍 Testando verificação do webhook...")
    try:
        params = {
            'hub.mode': 'subscribe',
            'hub.verify_token': VERIFY_TOKEN,
            'hub.challenge': 'test_challenge_123'
        }
        response = requests.get(f"{BASE_URL}/webhook", params=params, timeout=5)
        if response.status_code == 200 and response.text == 'test_challenge_123':
            print("✅ Verificação do webhook OK")
            return True
        else:
            print(f"❌ Verificação do webhook falhou: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"❌ Erro na verificação do webhook: {e}")
        return False

def test_webhook_message():
    """Testa o processamento de mensagem do webhook"""
    print("🔍 Testando processamento de mensagem...")
    
    # Payload de exemplo do WhatsApp
    test_payload = {
        "object": "whatsapp_business_account",
        "entry": [{
            "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
            "changes": [{
                "value": {
                    "messaging_product": "whatsapp",
                    "metadata": {
                        "display_phone_number": "15550559999",
                        "phone_number_id": "123456789"
                    },
                    "messages": [{
                        "from": "5511999999999",
                        "id": "wamid.test123",
                        "timestamp": "1234567890",
                        "text": {
                            "body": "oi"
                        },
                        "type": "text"
                    }]
                },
                "field": "messages"
            }]
        }]
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/webhook", 
            json=test_payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Processamento de mensagem OK: {data}")
            return True
        else:
            print(f"❌ Processamento de mensagem falhou: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"❌ Erro no processamento de mensagem: {e}")
        return False

def run_all_tests():
    """Executa todos os testes"""
    print("🚀 Iniciando testes do chatbot WhatsApp...")
    print("=" * 50)
    
    tests = [
        ("Health Check", test_health_check),
        ("Verificação Webhook", test_webhook_verification),
        ("Processamento Mensagem", test_webhook_message)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 {test_name}")
        result = test_func()
        results.append((test_name, result))
        time.sleep(1)
    
    print("\n" + "=" * 50)
    print("📊 RESULTADOS DOS TESTES:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Total: {passed}/{len(tests)} testes passaram")
    
    if passed == len(tests):
        print("🎉 Todos os testes passaram! Chatbot está funcionando corretamente.")
    else:
        print("⚠️  Alguns testes falharam. Verifique a configuração.")
    
    return passed == len(tests)

if __name__ == "__main__":
    run_all_tests()

